
#set page(
  // 3 cm partout
  margin: (top: 30mm, bottom: 30mm, left: 30mm, right: 30mm),
)

#set text(size: 12pt, font: ("Arial", "Helvetica"))
#set par(justify: true)

// Pas d’alinéa (pas d’indentation de 1re ligne)
#set par(first-line-indent: 0pt)

// Petite fonction pratique
#let gap = v(6pt)

// ---------- PAGE DE TITRE ----------
#align(center)[

  #text(weight: "bold")[
    #upper("Titre du rapport")\
    #upper("Sous-titre (optionnel)")
  ]

  // Espace vertical
  #v(70mm)

  par\
  #upper("Prénom Nom")\
  #upper("Prénom Nom")\
  #upper("Prénom Nom")

  #v(20mm)

  présenté à\
  #upper("Prénom Nom")

  #v(70mm)

  Cégep Édouard-Montpetit\
  Projet scientifique de fin d’études en informatique\
  cours 360-4A3-ER, groupe 1010\
  4 mai 2026
]

#pagebreak()

// Pages liminaires : chiffres romains (i, ii, iii...) centrés en bas
#set page(numbering: "i", number-align: center)

// La page titre compte comme i (mais on n'affiche rien dessus)
// Donc la page suivante (TOC) doit être ii
#counter(page).update(2)

// ---------- TABLE DES MATIÈRES ----------
= TABLE DES MATIÈRES
#outline()

// ---------- LISTE DES FIGURES ----------
#pagebreak()
= LISTE DES FIGURES
#outline(
  title: none,
  target: figure,
)

// ---------- CORPS DU RAPPORT ----------
#pagebreak()

// Texte : chiffres arabes (1, 2, 3...) centrés en bas
#set page(numbering: "1", number-align: center)
#set heading(numbering: "1. ")

= INTRODUCTION

WHEN on board H.M.S. 'Beagle,' as naturalist, I was much struck with certain facts in the distribution of the inhabitants of South America, and in the geological relations of the present to the past inhabitants of that continent. These facts seemed to me to throw some light on the origin of species—that mystery of mysteries, as it has been called by one of our greatest philosophers. On my return home, it occurred to me, in 1837, that something might perhaps be made out on this question by patiently accumulating and reflecting on all sorts of facts which could possibly have any bearing on it. After five years' work I allowed myself to speculate on the subject, and drew up some short notes; these I enlarged in 1844 into a sketch of the conclusions, which then seemed to me probable: from that period to the present day I have steadily pursued the same object. I hope that I may be excused for entering on these personal details, as I give them to show that I have not been hasty in coming to a decision.

Comme on peut l’observer à la figure @glacier, le temps de calcul augmente rapidement avec la taille des données.

#figure(
  image("images/figure1.png", width: 80%),
  caption: [
    Évolution du temps de calcul.
  ],
) <glacier>


== Contexte et motivation

My work is now nearly finished; but as it will take me two or three more years to complete it, and as my health is far from strong, I have been urged to publish this Abstract. I have more especially been induced to do this, as Mr. Wallace, who is now studying the natural history of the Malay archipelago, has arrived at almost exactly the same general conclusions that I have on the origin of species. Last year he sent to me a memoir on this subject, with a request that I would forward it to Sir Charles Lyell, who sent it to the Linnean Society, and it is published in the third volume of the Journal of that Society. Sir C. Lyell and Dr. Hooker, who both knew of my work—the latter having read my sketch of 1844—honoured me by thinking it advisable to publish, with Mr. Wallace's excellent memoir, some brief extracts from my manuscripts.

== Question de recherche

The Fibonacci sequence is defined through the
recurrence relation $F_n = F_(n-1) + F_(n-2)$.
It can also be expressed in _closed form:_

$
  F_n = round(1 / sqrt(5) phi.alt^n), quad
  phi.alt = (1 + sqrt(5)) / 2.
$


// ---------- BIBLIOGRAPHIE ----------
#pagebreak()
#set heading(numbering: none)

= BIBLIOGRAPHIE

// Retrait suspendu
#set par(hanging-indent: 12mm)

Darwin, C. (1859). _On the origin of species by means of natural selection_. John Murray.

Turing, A. M. (1950). Computing machinery and intelligence. _Mind_, 59(236), 433–460.


