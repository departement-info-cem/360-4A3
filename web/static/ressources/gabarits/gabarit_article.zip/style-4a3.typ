// ============================================================
// 360-4A3 — Style d'article scientifique
// Cégep Édouard-Montpetit
//
// Les étudiant·es ne devraient normalement pas modifier ce fichier.
// ============================================================

#let article-4a3(
  title: [],
  authors: (),
  abstract: [],
  keywords: (),
  body,
) = {
  set page(
    paper: "us-letter",
    margin: (
      top: 16mm,
      bottom: 17mm,
      left: 16mm,
      right: 16mm,
    ),
    columns: 2,
    numbering: "1",
  )

  set columns(gutter: 7mm)

  set text(
    font: "Libertinus Sans",
    size: 9.7pt,
  )

  set par(
    justify: true,
    leading: 0.74em,
    spacing: 0.56em,
  )

  set heading(
    numbering: "1.",
    outlined: false,
  )

  show heading.where(level: 1): it => {
    v(0.72em)
    block(
      above: 0.18em,
      below: 0.42em,
    )[
      #text(size: 11pt, weight: "bold")[#it]
    ]
  }

  show heading.where(level: 2): it => {
    block(
      above: 0.45em,
      below: 0.22em,
    )[
      #text(size: 9.8pt, weight: "bold")[#it.body]
    ]
  }

  show figure.caption: it => {
    set text(size: 8.7pt)
    it
  }

  place(
    top + center,
    float: true,
    scope: "parent",
    clearance: 7mm,
  )[
    #align(center)[
      #text(size: 16.5pt, weight: "bold")[#title]
      #v(4.5pt)

      #text(size: 9.8pt)[
        #for (i, author) in authors.enumerate() {
          if i > 0 { [ · ] }
          author
        }
      ]

      #v(2pt)

      #text(size: 8.6pt, style: "italic")[
        Cégep Édouard-Montpetit
      ]

      #v(7pt)
    ]

    #block(
      inset: (x: 7pt, y: 6pt),
      stroke: (
        top: 0.6pt + luma(165),
        bottom: 0.6pt + luma(165),
      ),
    )[
      #set par(justify: true, leading: 0.68em, spacing: 0.38em)
      #text(size: 8.9pt)[
        *Résumé — Abstract.* #abstract

        #v(3.5pt)

        *Mots-clés — Keywords.* #keywords.join(", ")
      ]
    ]

    #v(5pt)
  ]

  body
}

// Figure standard.
#let scientific-figure(content, caption: []) = {
  figure(
    content,
    caption: caption,
    kind: image,
    supplement: [Figure],
  )
}

// Tableau scientifique simple : sans traits verticaux,
// avec lignes horizontales seulement.
#let scientific-table(
  columns,
  header,
  rows,
  caption: [],
  align: left,
) = {
  figure(
    table(
      columns: columns,
      align: align,
      inset: (x: 4.5pt, y: 3.2pt),
      stroke: none,

      table.hline(stroke: 0.8pt),
      ..header,
      table.hline(stroke: 0.55pt),
      ..rows,
      table.hline(stroke: 0.8pt),
    ),
    caption: caption,
    kind: table,
    supplement: [Tableau],
  )
}

// Références non numérotées.
#let references(path) = {
  v(0.8em)
  heading(numbering: none)[Références]
  bibliography(
    path,
    style: "ieee",
    title: none,
  )
}
