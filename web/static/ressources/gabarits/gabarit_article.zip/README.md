# Gabarit d'article scientifique — 360-4A3

## Structure du projet

- `article.typ` : fichier principal à modifier.
- `style-4a3.typ` : mise en page de l'article. Ne pas modifier normalement.
- `references.bib` : bibliographie.
- `figures/` : figures, graphiques et images de l'article.

## Longueur

- Maximum 6 pages, références exclues.
- Aucun nombre minimal de pages ou de mots.
- Le résumé doit contenir environ 150 à 250 mots.

## Équations

Écrivez les équations directement dans Typst plutôt que de les insérer sous
forme d'image. Le fichier `article.typ` contient un exemple.

## Figures

Le gabarit utilise `figures/figure1.svg` comme exemple.
Déposez votre fichier `figure1.svg` dans le dossier `figures/`.

Pour vos propres graphiques, exportez de préférence en SVG lorsque possible.

## Citations

Ajoutez toutes vos sources dans `references.bib`. Chaque source possède une
clé unique que vous utilisez dans le texte, par exemple `@hubble1929`.

La liste des références est générée automatiquement selon le style IEEE.
