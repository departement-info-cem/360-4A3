// ============================================================
// 360-4A3 — Article scientifique
// ============================================================
//
// Modifiez principalement ce fichier.
//
// Les règles de mise en page se trouvent dans style-4a3.typ.
// Il n'est normalement pas nécessaire de modifier ce fichier.
//
// Les références bibliographiques se trouvent dans references.bib.
// Pour citer une source : @nom-de-la-cle
//
// Déposez vos images dans le dossier figures/.
//

#import "style-4a3.typ": article-4a3, scientific-figure, scientific-table, references

#show: article-4a3.with(
  title: [Titre de votre article scientifique],
  authors: (
    [Prénom Nom],
    [Prénom Nom],
    [Prénom Nom],
  ),
  abstract: [
    Rédigez ici un résumé de *150 à 250 mots*. Présentez brièvement le contexte,
    la question de recherche, la méthodologie, les principaux résultats et la
    conclusion. Le résumé doit pouvoir être compris sans lire le reste de
    l'article.
  ],
  keywords: (
    [mot-clé 1],
    [mot-clé 2],
    [mot-clé 3],
    [mot-clé 4],
  ),
)

= Introduction

Présentez le contexte scientifique et le phénomène étudié.

Expliquez pourquoi le problème est pertinent et introduisez les connaissances
nécessaires pour comprendre votre étude. Appuyez les informations scientifiques
importantes sur des références lorsque nécessaire.

Terminez l'introduction en formulant clairement votre *question de recherche*
et l'objectif de votre étude.

Vos citations bibliographiques peuvent être ajoutées simplement avec les clés
présentes dans le fichier `references.bib`, par exemple @hubble1929 et
@fisher1936. Utilisez autant de sources pertinentes que nécessaire pour
appuyer votre article.


= Méthodologie

Décrivez comment vous avez réalisé votre étude.

Présentez, selon votre projet :

- les données utilisées et leur provenance;
- la préparation ou la transformation des données;
- la méthode de génération des données, dans le cas d'une simulation;
- les algorithmes, modèles ou simulations utilisés;
- les paramètres étudiés;
- les expériences ou comparaisons réalisées;
- les choix méthodologiques importants.

N'insérez pas de code Python dans l'article. Expliquez plutôt la démarche
et les méthodes utilisées.

Lorsque pertinent, présentez directement les équations nécessaires à la
compréhension de votre méthode. Par exemple, la moyenne des valeurs observées
peut être calculée selon :

$ bar(x) = 1/n sum_(i=1)^n x_i $

où $n$ représente le nombre d'observations et $x_i$ la valeur de
l'observation $i$.


= Résultats

Présentez les résultats importants permettant de répondre à votre question
de recherche.

Chaque figure ou tableau doit être mentionné et interprété dans le texte.
Par exemple, la @fig-resultats1 présente la distribution spatiale des
différentes espèces d'arbres recensées dans le parc de la Chaudière.

#scientific-figure(
  image("figures/figure1.svg", width: 100%),
  caption: [Localisation des arbres recensés dans le parc de la Chaudière selon leur espèce.],
) <fig-resultats1>

Un tableau peut être créé ainsi :

#scientific-table(
  (1.2fr, 1fr, 1fr),
  (
    [*Condition*], [*Mesure A*], [*Mesure B*],
  ),
  (
    [A], [12,4], [8,1],
    [B], [14,8], [9,3],
  ),
  align: (left, center, center),
  caption: [Exemple de tableau présentant deux mesures pour deux conditions.],
) <tab-exemple>


= Discussion

Interprétez vos résultats plutôt que de simplement les répéter.

Discutez notamment :

- de ce que montrent vos résultats;
- de leur lien avec la question de recherche;
- des tendances ou comportements observés;
- des résultats inattendus;
- des explications possibles;
- des limites des données, du modèle ou de la méthode;
- des biais ou sources d'incertitude;
- de ce qui pourrait être amélioré;
- des expériences qui pourraient prolonger votre étude.

La discussion doit distinguer clairement ce qui est *observé* de ce qui est
*interprété*.


= Conclusion

Répondez directement à votre question de recherche.

Résumez brièvement les principaux résultats et ce que votre étude permet
raisonnablement de conclure.

N'introduisez pas de nouveaux résultats dans cette section.


#references("references.bib")
