# Figures

Déposez dans ce dossier les figures, graphiques et images utilisées dans l'article.

Le gabarit utilise `figure1.svg` comme figure d'exemple.

Formats recommandés :

- `.svg` pour les graphiques générés avec Python;
- `.png` ou `.jpeg` pour les images matricielles lorsque nécessaire.

Utilisez des noms de fichiers courts et descriptifs, par exemple :

- `orbite.svg`
- `comparaison-modeles.svg`
- `image-neurone.png`
