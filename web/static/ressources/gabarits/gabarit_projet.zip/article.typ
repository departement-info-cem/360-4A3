// ============================================================
// 360-4A3 — Projet scientifique
// ============================================================
//
// Ce document évoluera pendant toute la session.
//
// SEMAINE 5 : vous remettez la proposition de projet.
// SEMAINE 13 : vous poursuivez dans CE MÊME DOCUMENT pour produire
//              l'article scientifique final.
//
// Modifiez principalement ce fichier.
// ============================================================

#import "style-4a3.typ": article-4a3, scientific-figure, scientific-table, references

#show: article-4a3.with(
  title: [Titre de votre projet scientifique],

  authors: (
    [Prénom Nom],
    [Prénom Nom],
    [Prénom Nom],
  ),

  // PROPOSITION — SEMAINE 5 :
  // laissez le résumé et les mots-clés à `none`.
  //
  // ARTICLE FINAL — SEMAINE 13 :
  // remplacez `none` par votre résumé et vos mots-clés.
  //
  // Exemple :
  // abstract: [
  //   Votre résumé de 150 à 250 mots...
  // ],
  //
  // keywords: (
  //   [mot-clé 1],
  //   [mot-clé 2],
  //   [mot-clé 3],
  //   [mot-clé 4],
  // ),

  abstract: none,
  keywords: none,
)


// ============================================================
// PROPOSITION DE PROJET — SEMAINE 5
// ============================================================

= Introduction

Présentez le contexte général du projet, le phénomène ou le problème étudié
et expliquez pourquoi ce sujet est pertinent scientifiquement.

Formulez clairement votre *question de recherche principale* ainsi que,
si nécessaire, une ou deux sous-questions.

Vos citations bibliographiques peuvent être ajoutées avec les clés présentes
dans le fichier `references.bib`, par exemple @hubble1929 et @fisher1936.


= Données ou expérience envisagée

Décrivez les données ou l'expérience numérique que vous prévoyez utiliser.

Selon votre projet, précisez notamment :

- le type de données : réelles ou générées;
- leur provenance, si elles existent déjà;
- le principe de la simulation ou de l'expérience numérique;
- le volume approximatif des données;
- les contraintes déjà connues.


= Méthodologie prévue

Expliquez comment vous comptez répondre à votre question de recherche.

Présentez les grandes étapes prévues de votre démarche :

- préparation ou génération des données;
- algorithmes, modèles ou simulations envisagés;
- paramètres à étudier;
- types d'analyses, de mesures ou de comparaisons prévus;
- visualisations envisagées.

Il n'est pas nécessaire de fournir des détails techniques exhaustifs à ce stade.

Lorsque pertinent, vous pouvez écrire directement vos équations dans Typst.
Par exemple :

$ bar(x) = 1/n sum_(i=1)^n x_i $


= Faisabilité et limites

Discutez brièvement :

- des défis techniques anticipés;
- des limites possibles des données ou du modèle;
- des hypothèses importantes;
- des éléments du projet qui pourraient devoir être ajustés.


// ============================================================
// ÉVOLUTION VERS L'ARTICLE SCIENTIFIQUE FINAL — SEMAINE 13
// ============================================================
//
// Après la proposition :
// - CONSERVEZ ce document;
// - RÉVISEZ l'introduction selon la rétroaction reçue;
// - INTÉGREZ "Données ou expérience envisagée" à la Méthodologie;
// - REMPLACEZ "Méthodologie prévue" par la méthodologie réellement utilisée;
// - INTÉGREZ les limites pertinentes à la Discussion;
// - AJOUTEZ Résultats, Discussion et Conclusion;
// - ACTIVEZ le résumé et les mots-clés dans l'en-tête.
//
// La structure finale devient :
// 1. Introduction
// 2. Méthodologie
// 3. Résultats
// 4. Discussion
// 5. Conclusion
// Références
//
// Les sections ci-dessous sont laissées en commentaire jusqu'au moment
// où vous en aurez besoin.
//

/*
= Résultats

Présentez les résultats importants permettant de répondre à votre question
de recherche.

Chaque figure ou tableau doit être mentionné et interprété dans le texte.

#scientific-figure(
  image("figures/figure1.svg", width: 100%),
  caption: [Description claire de la figure.],
) <fig-resultats1>


= Discussion

Interprétez vos résultats plutôt que de simplement les répéter.

Discutez notamment :

- de ce que montrent vos résultats;
- de leur lien avec votre question de recherche;
- des tendances ou comportements observés;
- des résultats inattendus;
- des explications possibles;
- des limites des données, du modèle ou de la méthode;
- des biais ou sources d'incertitude;
- de ce qui pourrait être amélioré.


= Conclusion

Répondez directement à votre question de recherche.

Résumez brièvement les principaux résultats et ce que votre étude permet
raisonnablement de conclure.
*/


#references("references.bib")
