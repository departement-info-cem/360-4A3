# Projet scientifique — 360-4A3

Ce projet Typst est conçu pour être utilisé pendant toute la session.

## Semaine 5 — Proposition de projet

Commencez avec les sections déjà présentes dans `article.typ` :

1. Introduction
2. Données ou expérience envisagée
3. Méthodologie prévue
4. Faisabilité et limites
5. Références

Le résumé et les mots-clés demeurent désactivés.

## Pendant la session

Continuez à travailler dans le même projet Typst :

- améliorez l'introduction;
- ajustez votre méthodologie;
- ajoutez progressivement vos références;
- déposez vos graphiques dans `figures/`;
- tenez compte de la rétroaction reçue.

## Semaine 13 — Article scientifique final

Ne créez pas un nouveau document.

Transformez progressivement la proposition en article scientifique :

1. Introduction
2. Méthodologie
3. Résultats
4. Discussion
5. Conclusion
6. Références

Activez également le résumé et les mots-clés dans l'en-tête de `article.typ`.

## Fichiers

- `article.typ` : document principal à modifier.
- `style-4a3.typ` : mise en page; ne pas modifier normalement.
- `references.bib` : bibliographie qui évolue pendant toute la session.
- `figures/` : figures et graphiques.
