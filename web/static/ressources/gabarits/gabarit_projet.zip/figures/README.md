# Figures

Déposez ici les figures, graphiques et images utilisées dans votre projet.

Formats recommandés :

- `.svg` pour les graphiques générés avec Python;
- `.png` ou `.jpeg` lorsque nécessaire.
